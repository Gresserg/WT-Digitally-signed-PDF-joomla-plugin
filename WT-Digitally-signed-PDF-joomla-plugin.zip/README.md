# WT Digitally signed PDF Joomla 3 and 4 plugin
Plugin for displaying digital signature data from PDF files signed with attached signature (the signature is inside the PDF file). 
Use `{wt_ds_pdf}images/path_to_file.pdf{/wt_ds_pdf}` in articles or elsewhere content plugins working.
More info in https://web-tolk.ru/dev/joomla-plugins/wt-digitally-signed-pdf.html
